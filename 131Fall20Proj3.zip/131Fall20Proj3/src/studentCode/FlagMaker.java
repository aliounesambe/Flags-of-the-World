package studentCode;
import java.awt.Color;
import GridTools.MyGrid;

public class FlagMaker {

	public static void drawFlag(MyGrid grid, int countryCode) {
		
		/* Remove this comment and implement this method 
		 * according to the project description.
		 */
		
	}
	
}